"""
序列化器 - 数据序列化与验证
"""
from rest_framework import serializers
from .models import Article, Faq, Contact, SiteConfig, Product, Certificate, Milestone, ArticleLike


class SiteConfigSerializer(serializers.ModelSerializer):
    """站点配置序列化器"""
    class Meta:
        model = SiteConfig
        fields = '__all__'


class ArticleListSerializer(serializers.ModelSerializer):
    """文章列表序列化器"""
    class Meta:
        model = Article
        fields = ['id', 'title', 'seo_title', 'seo_keywords', 'seo_description',
                  'category', 'cover', 'summary', 'author', 'views', 'is_top',
                  'created_at']


class ArticleDetailSerializer(serializers.ModelSerializer):
    """文章详情序列化器"""
    class Meta:
        model = Article
        fields = '__all__'


class FaqSerializer(serializers.ModelSerializer):
    """FAQ序列化器"""
    class Meta:
        model = Faq
        fields = '__all__'


class ContactSerializer(serializers.ModelSerializer):
    """联系表单序列化器"""
    class Meta:
        model = Contact
        fields = ['id', 'name', 'phone', 'email', 'message', 'source',
                  'is_handled', 'created_at']
        read_only_fields = ['id', 'is_handled', 'created_at']

    def validate_phone(self, value):
        """手机号简单验证"""
        if not value or len(value) < 6:
            raise serializers.ValidationError('请输入有效的联系电话')
        return value


class ProductSerializer(serializers.ModelSerializer):
    """产品序列化器"""
    class Meta:
        model = Product
        fields = '__all__'


class CertificateSerializer(serializers.ModelSerializer):
    """资质证书序列化器"""
    class Meta:
        model = Certificate
        fields = '__all__'


class MilestoneSerializer(serializers.ModelSerializer):
    """企业历程序列化器"""
    class Meta:
        model = Milestone
        fields = '__all__'


class ArticleLikeSerializer(serializers.ModelSerializer):
    """文章点赞序列化器"""
    class Meta:
        model = ArticleLike
        fields = ['id', 'article', 'ip_address', 'created_at']
        read_only_fields = ['id', 'ip_address', 'created_at']
