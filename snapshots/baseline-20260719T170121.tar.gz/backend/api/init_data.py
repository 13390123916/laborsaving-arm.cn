"""
初始化数据脚本 - 创建站点配置、FAQ、产品、示例资讯
运行方式：python3.11 manage.py shell < init_data.py
"""
from api.models import SiteConfig, Faq, Article, Product, Certificate, Milestone

# ===== 站点配置 =====
config, created = SiteConfig.objects.get_or_create(
    id=1,
    defaults={
        'site_name': 'LABOR-SAVING 气动助力机械臂',
        'site_title': '气动助力机械臂厂家 | 工业自动化助力解决方案 | LABOR-SAVING',
        'site_keywords': '气动助力机械臂,助力臂,平衡吊,工业机械臂,自动化产线,机械臂厂家',
        'site_description': 'LABOR-SAVING 专注气动助力机械臂研发生产，提供工业自动化助力解决方案，产品广泛应用于搬运、装配、焊接等场景。',
        'company_name': 'LABOR-SAVING 智能装备有限公司',
        'company_intro': 'LABOR-SAVING 智能装备有限公司成立于2015年，是一家专业从事气动助力机械臂、平衡吊及工业自动化设备研发、生产、销售的高新技术企业。公司拥有一支经验丰富的研发团队，产品广泛应用于汽车制造、机械加工、电子装配、物流仓储等行业，致力于为企业提供安全、高效、人性化的助力解决方案。',
        'founded_year': 2015,
        'company_scale': '员工100-300人，厂房面积15000㎡',
        'qualifications': '高新技术企业认证、ISO9001质量管理体系认证、CE认证、多项实用新型专利',
        'office_address': '辽宁省沈阳市浑南区文溯街19-1号',
        'service_scope': '全国及海外工业自动化市场，提供售前咨询、方案设计、安装调试、售后维护全流程服务',
        'contact_phone': '400-888-xxxx',
        'contact_email': 'sales@laborsaving-arm.cn',
        'contact_qq': '800xxxxxx',
        # 地理位置（本地SEO / GEO 结构化数据 - 沈阳浑南文溯街坐标）
        'latitude': 41.736500,
        'longitude': 123.492000,
        'address_region': '辽宁省',
        'address_locality': '沈阳市',
        'postal_code': '110179',
        # SEO 验证与统计代码（上线前替换为真实值）
        # 百度站长验证: 从百度站长平台获取
        'baidu_verify': 'code-labor-saving-baidu-verify',
        # 百度统计 ID: hm.baidu.com 中的跟踪 ID (格式: xxxxxxxx)
        'baidu_tongji': '0000000000000000',
        # 百度推送 Token: 百度站长平台-链接提交-主动推送 获取
        'baidu_push_token': '',
        # 360站长验证: 从 360 站长平台获取
        'qihu_verify': 'code-360-qihoo-verify',
        # 搜狗站长验证: 从搜狗站长平台获取
        'sogou_verify': 'code-sogou-site-verify',
        # Google Search Console 验证
        'google_verify': 'google-search-console-verify-code',
        # Google Analytics 4 测量 ID (格式: G-xxxxxxxxxx)
        'google_ga_id': 'G-0000000000',
        # Google Ads 转化 ID
        'google_ads_id': '',
        # Google Tag Manager 容器 ID (格式: GTM-xxxxxxx)
        'gtm_id': 'GTM-0000000',
    }
)
print(f"站点配置: {'创建' if created else '已存在'}")

# ===== FAQ 数据（15条采购高频问答）=====
faq_data = [
    {
        'question': '气动助力机械臂是什么？适合哪些场景使用？',
        'answer': '气动助力机械臂是一种利用压缩空气实现工件平衡悬浮的助力设备，操作人员只需施加很小的力即可移动重物。适合搬运、装配、上下料、焊接等工业场景。',
        'detail': '它采用气动平衡原理，使工件在任意位置处于"失重"状态，操作人员可轻松完成工件的升降、旋转、平移等动作，大幅降低劳动强度，提高作业安全性。广泛应用于汽车、机械、电子、食品等行业。',
        'category': '产品认知'
    },
    {
        'question': '气动助力机械臂和电动机械臂有什么区别？',
        'answer': '气动助力臂以压缩空气为动力，响应快、维护简单、防爆安全；电动机械臂精度更高、可控性强。选型需根据负载、精度和工况决定。',
        'detail': '气动方案适合重载、频繁搬运、防爆环境；电动方案适合高精度定位、复杂轨迹作业。两者可组合使用，我们提供混合方案设计。',
        'category': '选型对比'
    },
    {
        'question': '机械臂的载荷范围是多少？能否定制？',
        'answer': '标准产品载荷覆盖50kg-500kg，支持非标定制至1000kg以上。可根据工件尺寸、行程、旋转角度定制。',
        'detail': '我们提供从轻载到重载的全系列标准机型，同时拥有专业非标设计团队，可根据客户产线需求定制臂展、回转半径、夹具形式等参数。',
        'category': '技术参数'
    },
    {
        'question': '安装需要什么条件？现场需要预留什么？',
        'answer': '需提供0.6-0.8MPa洁净气源、380V或220V电源、吊顶承重结构。我们提供现场勘察和安装指导。',
        'detail': '安装前需确认气源压力稳定、管路布置合理，吊顶或立柱基础承载力满足要求。我司提供上门勘测服务，出具安装方案图纸。',
        'category': '安装部署'
    },
    {
        'question': '价格大概多少？影响报价的因素有哪些？',
        'answer': '标准机型数万元起，非标定制根据复杂程度报价。载荷、行程、夹具、传感器配置均影响价格。',
        'detail': '报价需综合负载能力、工作半径、自由度、夹具类型、安全配置等因素。建议提供工件图纸和工艺要求获取精准报价。',
        'category': '商务报价'
    },
    {
        'question': '交付周期是多久？',
        'answer': '标准机型7-15个工作日发货，非标定制30-45个工作日。紧急订单可协调加急。',
        'detail': '交付周期取决于设计复杂度、零部件库存及生产排期。签订合同时明确交期，关键节点提供进度反馈。',
        'category': '商务报价'
    },
    {
        'question': '设备质保多久？售后怎么保障？',
        'answer': '整机质保1年，核心部件2年。提供7×24小时技术响应，省内48小时上门。',
        'detail': '我们建立客户档案，定期回访保养。提供操作培训、备件供应、远程诊断等服务，确保设备长期稳定运行。',
        'category': '售后服务'
    },
    {
        'question': '机械臂操作和培训复杂吗？',
        'answer': '操作简便，普通工人经1-2小时培训即可上岗。我们提供现场操作和维保培训。',
        'detail': '人机工程学设计使操作省力直观，配套图文手册和视频教程。培训涵盖安全规范、日常点检、常见故障处理。',
        'category': '使用培训'
    },
    {
        'question': '可以配合现有生产线或机器人使用吗？',
        'answer': '可以。机械臂支持与 conveyor、AGV、工业机器人集成，提供标准通讯接口。',
        'detail': '我们提供与各类自动化设备的对接方案，支持IO、Modbus、Profinet等通讯协议，实现产线协同。',
        'category': '系统集成'
    },
    {
        'question': '气动助力臂安全吗？会掉落吗？',
        'answer': '多重安全设计：断气保护、机械锁止、紧急停止。即使断气工件也不会坠落。',
        'detail': '采用平衡阀+机械制动双重保护，气源中断时自动锁定位置。配备安全光幕、碰撞检测等选配安全模块。',
        'category': '安全规范'
    },
    {
        'question': '耗气量大吗？运行成本高吗？',
        'answer': '仅在动作时耗气，待机几乎零消耗。相比人工成本，投资回报期通常6-12个月。',
        'detail': '气动系统能效高，配合节气阀可进一步节能。以替代2名搬运工计算，年节省人力成本可观。',
        'category': '运行成本'
    },
    {
        'question': '支持哪些行业应用案例？',
        'answer': '已服务汽车、3C电子、家电、食品、医药等行业，提供变速箱装配、玻璃搬运等方案。',
        'detail': '我们积累大量行业案例，可参考同行业成熟方案快速落地，也可针对特殊工艺定制开发。',
        'category': '行业应用'
    },
    {
        'question': '如何选择合适的型号？',
        'answer': '提供工件重量、尺寸、搬运距离、节拍要求，我司工程师免费推荐型号。',
        'detail': '选型需综合考虑负载、工作半径、自由度、精度、环境。填写需求表后1个工作日内回复方案。',
        'category': '选型对比'
    },
    {
        'question': '有没有环保和噪音方面的考虑？',
        'answer': '气动系统无污染排放，运行噪音低于65dB，符合车间环保要求。',
        'detail': '采用低噪音消声器，可选静音气路设计。无油润滑选项满足洁净车间需求。',
        'category': '环保合规'
    },
    {
        'question': '可以分期付款或租赁吗？',
        'answer': '支持灵活商务方案，包括分期、以租代购。具体可咨询商务经理。',
        'detail': '针对资金压力大的客户，我们提供金融分期、设备租赁等模式，降低初期投入。',
        'category': '商务报价'
    },
]

for i, f in enumerate(faq_data):
    Faq.objects.get_or_create(
        question=f['question'],
        defaults={**f, 'sort_order': i}
    )
print(f"FAQ 数据: 共 {len(faq_data)} 条")

# ===== 产品数据（对应首页三大核心产品）=====
product_data = [
    {'name': '气动助力机械臂', 'icon': '🦾', 'description': '负载50-800kg，气动平衡技术，操作省力安全，广泛应用于搬运、装配、焊接等工业场景。支持非标定制夹具与附件。', 'category': '核心产品', 'sort_order': 0},
    {'name': '平衡吊', 'icon': '⚖️', 'description': '配合机械臂使用，实现工件精准平衡吊装。结构紧凑、安装方便，适用于狭小空间作业。', 'category': '核心产品', 'sort_order': 1},
    {'name': '定制自动化产线', 'icon': '🔧', 'description': '按需定制助力解决方案，与现有产线无缝集成。提供方案设计、设备制造、安装调试一站式服务。', 'category': '核心产品', 'sort_order': 2},
]

for p in product_data:
    Product.objects.get_or_create(name=p['name'], defaults=p)
print(f"产品数据: 共 {len(product_data)} 条")

# ===== 示例资讯（6-8篇，覆盖多分类）=====
news_data = [
    {
        'title': 'LABOR-SAVING 发布新一代重载气动助力机械臂',
        'category': '公司新闻',
        'summary': '新机型最大负载提升至800kg，采用轻量化铝合金臂体，操作更灵活。',
        'content': '近日，LABOR-SAVING 智能装备发布全新一代重载气动助力机械臂系列，最大负载能力提升至800kg，臂体采用航空级铝合金材料，自重减轻20%的同时刚性更强。\n\n新机型配备智能平衡系统，响应速度提升30%，并集成物联网模块，支持远程状态监控和故障预警。已在多家汽车主机厂投入使用，获得客户一致好评。',
        'is_top': True,
    },
    {
        'title': '气动助力机械臂在汽车焊装线的应用实践',
        'category': '行业资讯',
        'summary': '通过助力臂实现车门、总成件的省力搬运与精准定位，提升焊装效率。',
        'content': '在汽车焊装车间，车门、侧围等大型总成件搬运一直是痛点。传统人工搬运劳动强度大、定位精度低。\n\n引入气动助力机械臂后，操作工可轻松将工件送至夹具位置，配合视觉定位实现毫米级对位，单工位节拍缩短40%，工伤率显著下降。本文结合实际案例解析部署要点。',
    },
    {
        'title': '如何评估工厂是否需要引入助力机械臂',
        'category': '技术干货',
        'summary': '从搬运重量、频次、工伤风险三个维度判断助力的必要性。',
        'content': '企业在考虑自动化升级时，常困惑于是否需引入助力设备。建议从三方面评估：\n\n1. 单件重量超过15kg且每日搬运频次高；\n2. 存在腰肌劳损、砸伤等职业健康风险；\n3. 招工难、人工成本逐年上升。\n\n满足两项以上即值得投资，通常回报期在一年以内。',
    },
    {
        'title': '零重力平衡臂在家电装配线的应用',
        'category': '行业应用',
        'summary': '为某大型家电企业部署12台平衡臂，实现洗衣机内筒装配工位效率提升35%。',
        'content': '某知名家电企业在洗衣机内筒装配线上引入LABOR-SAVING零重力平衡臂系统，单台设备日均搬运200次以上。\n\n操作人员反馈：装配精度显著提升，劳动强度大幅下降。该企业已在其三个生产基地推广部署，累计安装超过50台设备，年节省人力成本数百万元。',
    },
    {
        'title': '气动助力设备日常维护保养指南',
        'category': '技术干货',
        'summary': '掌握五点日常点检方法，有效延长设备使用寿命，降低故障率。',
        'content': '正确的日常维护是保障助力机械臂长期稳定运行的关键。建议每日开工前进行以下点检：\n\n1. 检查气源压力是否在0.6-0.8MPa范围内；\n2. 确认管路接头无漏气；\n3. 测试制动系统是否可靠；\n4. 检查吊具和夹具紧固件；\n5. 清洁滑轨及导向机构。\n\n每月进行润滑油加注，每半年更换空气过滤器，可大幅降低非计划停机时间。',
    },
    {
        'title': '2025年工业自动化趋势：助力设备智能化升级',
        'category': '行业资讯',
        'summary': '助力设备接入工业物联网，实现预测性维护与效率优化。',
        'content': '随着工业4.0推进，传统气动助力设备正迎来智能化升级浪潮。新一代设备集成传感器、物联模块与边缘计算能力。\n\nLABOR-SAVING 推出的智能助力系统支持实时负载监测、能耗分析与故障预警，数据可直接上传至工厂MES系统，帮助企业实现精准产能规划与设备全生命周期管理。',
    },
]

for i, n in enumerate(news_data):
    Article.objects.get_or_create(
        title=n['title'],
        defaults={
            **n,
            'seo_title': n['title'],
            'seo_keywords': '气动助力机械臂,工业自动化,应用案例',
            'seo_description': n['summary'],
            'author': 'LABOR-SAVING 编辑部',
            'sort_order': i,
        }
    )
print(f"资讯数据: 共 {len(news_data)} 篇")

# ===== 资质证书数据 =====
certificate_data = [
    {'name': '高新技术企业认证', 'image_url': '', 'description': '国家高新技术企业认定证书', 'sort_order': 0},
    {'name': 'ISO9001质量管理体系', 'image_url': '', 'description': 'ISO9001:2015质量管理体系认证', 'sort_order': 1},
    {'name': 'CE安全认证', 'image_url': '', 'description': '欧盟CE安全认证', 'sort_order': 2},
    {'name': '实用新型专利证书', 'image_url': '', 'description': '多项气动助力设备实用新型专利', 'sort_order': 3},
    {'name': 'AAA级信用企业', 'image_url': '', 'description': '企业信用评价AAA级信用企业', 'sort_order': 4},
]

for c in certificate_data:
    Certificate.objects.get_or_create(name=c['name'], defaults=c)
print(f"资质证书数据: 共 {len(certificate_data)} 项")

# ===== 企业历程数据 =====
milestone_data = [
    {'year': '2015', 'title': '公司成立', 'description': 'LABOR-SAVING 智能装备有限公司在山东青岛正式成立。', 'sort_order': 0},
    {'year': '2016', 'title': '首款产品下线', 'description': '首款气动助力机械臂量产下线，通过CE安全认证。', 'sort_order': 1},
    {'year': '2018', 'title': '通过ISO9001认证', 'description': '建立标准化质量体系，产品线扩展至5大系列。', 'sort_order': 2},
    {'year': '2020', 'title': '服务客户突破300家', 'description': '累计服务客户超过300家，年销售额突破8000万元。', 'sort_order': 3},
    {'year': '2022', 'title': '新厂房投入使用', 'description': '15000㎡新厂房建成投产，产能提升200%。', 'sort_order': 4},
    {'year': '2023', 'title': '获高新技术企业认定', 'description': '通过国家高新技术企业认定。', 'sort_order': 5},
    {'year': '2024', 'title': '发布智能助力系统', 'description': '推出集成物联网模块的智能气动助力系统。', 'sort_order': 6},
]

for m in milestone_data:
    Milestone.objects.get_or_create(year=m['year'], title=m['title'], defaults=m)
print(f"企业历程数据: 共 {len(milestone_data)} 项")

print("\n初始化完成！")
