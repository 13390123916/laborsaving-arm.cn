# AGENTS.md —— 本工作区 agent 启动约定

> 本文件供所有在本工作区（`/workspace`）启动的对话/agent 阅读并遵循。
> 配套全局策略：`/root/.codebuddy/baselines/STRATEGY.md`

## 强制启动流程

**任何对话开始工作的第一步，必须执行：**

```bash
/root/.codebuddy/baselines/_bin/load_baseline.sh
```

该命令会：
- 自动识别本项目（`laborsaving-arm-cn`），加载最新基线到 `/workspace`；
- 若本地快照缺失（沙箱被整体重置），自动从 GitHub `main` 分支克隆完整工程兜底恢复；
- 若 `/workspace` 存在未提交改动，先自动存安全快照，绝不丢失工作。

> 只有在 `/workspace` 已恢复到最新基线状态后，才进行后续开发。

## 收尾流程

- **提交即自动保存基线**：`/workspace/.git/hooks/post-commit` 钩子会在每次 `git commit` 后自动保存一份基线并镜像到 GitHub `<baselines>` 分支，无需手动操作。
- 完成一个阶段性任务后，正常 `git commit` 即可；若想立即落一份基线（未提交前），运行：
  ```bash
  /root/.codebuddy/baselines/_bin/save_baseline.sh
  ```

## 原则

- 历史基线**永不删除**，可随时回滚：`load_baseline.sh laborsaving-arm-cn <基线id>`。
- 不改动 `/root/.codebuddy/baselines/` 下的 `manifest.json` 历史记录（仅追加）。
- 写令牌存于本地 `/root/.codebuddy/baselines/.git-credentials`（权限 600），不写入任何代码或日志。
