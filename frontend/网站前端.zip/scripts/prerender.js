import { spawn } from 'node:child_process'
import { mkdir, writeFile } from 'node:fs/promises'
import { dirname } from 'node:path'
import puppeteer from 'puppeteer-core'
import http from 'node:http'
import net from 'node:net'

const DIST = 'dist'
const ROUTES = [
  '/',
  '/about',
  '/products',
  '/products/balance-arm',
  '/products/pneumatic-balancer',
  '/products/servo-assist',
  '/franchise',
  '/news',
  '/news/new-lightweight-arm',
  '/news/pneumatic-vs-servo',
  '/news/franchise-open',
  '/faq',
  '/contact',
  '/404'
]

const CHROMIUM = process.env.CHROME_BIN || process.env.CHROME_PATH || '/usr/bin/chromium'

function getFreePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer()
    srv.listen(0, '127.0.0.1', () => {
      const port = srv.address().port
      srv.close(() => resolve(port))
    })
    srv.on('error', reject)
  })
}

function waitForServer(url, timeout = 20000) {
  const start = Date.now()
  return new Promise((resolve, reject) => {
    const check = () => {
      http.get(url, { timeout: 1000 }, (res) => {
        if (res.statusCode < 400) return resolve()
        retry()
      }).on('error', retry)
    }
    const retry = () => {
      if (Date.now() - start > timeout) return reject(new Error('预览服务启动超时'))
      setTimeout(check, 300)
    }
    check()
  })
}

async function startPreview(port) {
  // 关键：显式绑定 127.0.0.1（IPv4）。vite preview 默认绑定 localhost（解析为 ::1 IPv6），
  // 而 waitForServer 通过 http.get('127.0.0.1') 探测，IPv4/IPv6 不匹配会导致探测超时。
  const proc = spawn('pnpm', ['exec', 'vite', 'preview', '--host', '127.0.0.1', '--port', String(port)], {
    cwd: process.cwd(),
    stdio: ['ignore', 'pipe', 'pipe']
  })

  let output = ''
  const onData = (data) => {
    output += data.toString()
  }
  proc.stdout.on('data', onData)
  proc.stderr.on('data', onData)

  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      proc.stdout.off('data', onData)
      proc.stderr.off('data', onData)
      resolve()
    }, 10000)
    const check = () => {
      if (output.includes('Local:') || output.includes('http://')) {
        clearTimeout(timer)
        proc.stdout.off('data', onData)
        proc.stderr.off('data', onData)
        resolve()
      }
    }
    proc.stdout.on('data', check)
    proc.stderr.on('data', check)
  })

  await waitForServer(`http://127.0.0.1:${port}/`)
  console.log(`✓ 预览服务已启动: http://127.0.0.1:${port}/`)
  return proc
}

async function prerender() {
  const port = await getFreePort()
  const server = await startPreview(port)
  let browser

  try {
    browser = await puppeteer.launch({
      executablePath: CHROMIUM,
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
    })

    for (const route of ROUTES) {
      const page = await browser.newPage()
      try {
        await page.goto(`http://127.0.0.1:${port}${route}`, {
          waitUntil: 'networkidle0',
          timeout: 30000
        })
        await new Promise(r => setTimeout(r, 800))
        const html = await page.content()
        const filePath = route === '/' ? `${DIST}/index.html` : `${DIST}${route}/index.html`
        await mkdir(dirname(filePath), { recursive: true })
        await writeFile(filePath, html)
        console.log(`✓ 预渲染: ${route} -> ${filePath}`)
      } catch (err) {
        console.error(`✗ 预渲染失败: ${route}`, err.message)
      } finally {
        await page.close()
      }
    }
  } finally {
    if (browser) await browser.close()
    server.kill('SIGTERM')
  }
}

prerender().catch(err => {
  console.error('预渲染脚本异常:', err)
  process.exit(1)
})
