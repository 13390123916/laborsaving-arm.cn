<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import SiteHeader from './components/SiteHeader.vue'
import SiteFooter from './components/SiteFooter.vue'
import FloatPhone from './components/FloatPhone.vue'

const route = useRoute()
// 404 页不显示悬浮电话，避免干扰
const showFloatPhone = computed(() => route.name !== 'NotFound')
</script>

<template>
  <div class="app-root">
    <SiteHeader />
    <main id="main">
      <router-view />
    </main>
    <SiteFooter />
    <FloatPhone v-if="showFloatPhone" />
  </div>
</template>

<style scoped>
.app-root {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}
#main {
  flex: 1;
}
</style>
