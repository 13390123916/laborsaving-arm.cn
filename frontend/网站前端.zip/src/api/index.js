import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' }
})

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const msg = err?.response?.data?.msg || err.message || '网络请求失败，请稍后重试'
    return Promise.reject(new Error(msg))
  }
)

export function normalizeResponse(promise) {
  return promise.then((data) => {
    if (data && typeof data === 'object') {
      if (data.code === 0 || data.code === 200) return data.data
      throw new Error(data.msg || '请求失败')
    }
    return data
  })
}

export default api
