import api, { normalizeResponse } from './index'
import fallbackData from '@/data/fallback.json'

export const siteApi = {
  get: () => normalizeResponse(api.get('/site-config/')).catch(() => fallbackData.siteConfig)
}

export const newsApi = {
  categories: () => normalizeResponse(api.get('/news-categories/')).catch(() => fallbackData.newsCategories),
  list: (params) => normalizeResponse(api.get('/news/', { params })).catch(() => fallbackData.newsList),
  detail: (slug) => normalizeResponse(api.get(`/news/${slug}/`)).catch(() => fallbackData.newsDetail)
}

export const faqApi = {
  list: () => normalizeResponse(api.get('/faqs/')).catch(() => fallbackData.faqList)
}

export const franchiseApi = {
  submit: (payload) => normalizeResponse(api.post('/franchise/', payload))
}

export const purchaseApi = {
  submit: (payload) => normalizeResponse(api.post('/purchase/', payload))
}
