import { defineStore } from 'pinia'
import { ref } from 'vue'
import { siteApi } from '@/api/content'

export const useSiteStore = defineStore('site', () => {
  const config = ref(null)
  const loading = ref(false)
  const error = ref(null)

  async function fetchConfig() {
    if (config.value) return config.value
    loading.value = true
    error.value = null
    try {
      config.value = await siteApi.get()
    } catch (err) {
      error.value = err.message
      console.warn('站点配置获取失败，使用本地兜底', err)
    } finally {
      loading.value = false
    }
    return config.value
  }

  return { config, loading, error, fetchConfig }
})
