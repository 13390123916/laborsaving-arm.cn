<script setup>
import { ref, reactive, computed } from 'vue'
import { useTrack } from '@/composables/useTrack'
import { useLeadSource } from '@/composables/useLeadSource'

const props = defineProps({
  leadType: { type: String, default: 'franchise' }, // franchise | purchase
  title: { type: String, default: '' },
  submitLabel: { type: String, default: '提交咨询' },
  apiSubmit: { type: Function, required: true }
})

const { trackLeadSubmit } = useTrack()
const { detect } = useLeadSource()

const emit = defineEmits(['success'])

const form = reactive({
  name: '',
  phone: '',
  company: '',
  region: '',
  budget: '',
  message: '',
  agree: false,
  honeypot: ''
})

const errors = reactive({})
const submitting = ref(false)
const success = ref(false)
const errorMsg = ref('')

const budgetOptions = ['10 万以下', '10-30 万', '30-50 万', '50 万以上', '暂未确定']
const regions = ['华东', '华南', '华北', '华中', '西南', '西北', '东北', '其他']

const showBudget = computed(() => props.leadType === 'franchise')
const showRegion = computed(() => props.leadType === 'franchise')

function validate() {
  Object.keys(errors).forEach(k => delete errors[k])
  errorMsg.value = ''
  let valid = true

  if (!form.name.trim()) { errors.name = '请输入姓名'; valid = false }
  if (!/\d{6,}/.test(form.phone.replace(/\s/g, ''))) { errors.phone = '请输入有效的电话号码'; valid = false }
  if (!form.message.trim()) { errors.message = '请输入留言内容'; valid = false }
  if (!form.agree) { errors.agree = '请同意隐私政策'; valid = false }
  if (form.honeypot) valid = false
  return valid
}

async function onSubmit() {
  if (submitting.value) return
  if (!validate()) return

  submitting.value = true
  success.value = false

  try {
    const leadSource = detect()
    const payload = {
      name: form.name.trim(),
      phone: form.phone.trim(),
      company: form.company.trim(),
      message: form.message.trim(),
      lead_source: leadSource,
      page_url: typeof window !== 'undefined' ? window.location.href : ''
    }
    if (showRegion.value) payload.region = form.region
    if (showBudget.value) payload.budget = form.budget

    await props.apiSubmit(payload)
    trackLeadSubmit(props.leadType, leadSource)
    success.value = true
    emit('success', payload)

    Object.assign(form, {
      name: '', phone: '', company: '', region: '', budget: '', message: '', agree: false, honeypot: ''
    })
  } catch (err) {
    errorMsg.value = err.message || '提交失败，请稍后重试'
  } finally {
    submitting.value = false
  }
}
</script>

<template>
  <form class="lead-form" @submit.prevent="onSubmit">
    <div v-if="props.title" class="h3" style="margin-bottom: 6px;">{{ props.title }}</div>
    <p class="text-muted" style="margin-bottom: 22px; font-size: .95rem;">填写下方信息，招商顾问将在 1 个工作日内与您联系。</p>

    <div v-if="success" class="form-success" role="status">提交成功，我们的招商顾问会尽快联系您。</div>
    <div v-if="errorMsg" class="form-error" role="alert">{{ errorMsg }}</div>

    <div class="honeypot" aria-hidden="true">
      <input type="text" v-model="form.honeypot" tabindex="-1" autocomplete="off">
    </div>

    <div class="form-group">
      <label class="form-label">姓名 <span class="required">*</span></label>
      <input v-model="form.name" type="text" class="input" placeholder="请输入您的姓名" autocomplete="name">
      <div v-if="errors.name" class="form-error">{{ errors.name }}</div>
    </div>

    <div class="form-group">
      <label class="form-label">电话 <span class="required">*</span></label>
      <input v-model="form.phone" type="tel" class="input" placeholder="请输入您的联系电话" autocomplete="tel">
      <div v-if="errors.phone" class="form-error">{{ errors.phone }}</div>
    </div>

    <div class="form-group">
      <label class="form-label">公司名称</label>
      <input v-model="form.company" type="text" class="input" placeholder="请输入公司名称（选填）">
    </div>

    <div v-if="showRegion" class="form-group">
      <label class="form-label">意向代理区域</label>
      <select v-model="form.region" class="select">
        <option value="">请选择区域</option>
        <option v-for="r in regions" :key="r" :value="r">{{ r }}</option>
      </select>
    </div>

    <div v-if="showBudget" class="form-group">
      <label class="form-label">投资预算区间</label>
      <select v-model="form.budget" class="select">
        <option value="">请选择预算</option>
        <option v-for="b in budgetOptions" :key="b" :value="b">{{ b }}</option>
      </select>
    </div>

    <div class="form-group">
      <label class="form-label">留言内容 <span class="required">*</span></label>
      <textarea v-model="form.message" class="textarea" placeholder="请描述您的需求或问题"></textarea>
      <div v-if="errors.message" class="form-error">{{ errors.message }}</div>
    </div>

    <div class="form-group">
      <label class="checkbox-row">
        <input v-model="form.agree" type="checkbox">
        <span>我已阅读并同意 <router-link to="/about" style="color: var(--red); text-decoration: underline;">隐私政策</router-link>，授权雷普赛维联系我以提供招商/采购咨询服务。</span>
      </label>
      <div v-if="errors.agree" class="form-error">{{ errors.agree }}</div>
    </div>

    <button type="submit" class="btn btn-red btn-block" :disabled="submitting">
      {{ submitting ? '提交中...' : props.submitLabel }}
    </button>

    <p class="text-muted" style="margin-top: 14px; font-size: .85rem; line-height: 1.5;">温馨提示：投资有风险，代理政策以双方签订的正式合同为准。机械臂参数与应用方案需结合实际工况评估。</p>
  </form>
</template>

<style scoped>
.lead-form {
  background: var(--bg-light);
  border-radius: var(--radius-lg);
  padding: 32px;
  color: var(--dark);
}
@media (max-width: 680px) {
  .lead-form {
    padding: 22px;
  }
}
</style>
