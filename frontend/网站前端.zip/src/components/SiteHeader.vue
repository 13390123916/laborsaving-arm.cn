<script setup>
import { ref, watch } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const open = ref(false)

watch(() => route.path, () => { open.value = false })

const navItems = [
  { path: '/', label: '首页' },
  { path: '/products', label: '产品中心' },
  { path: '/franchise', label: '全国招商' },
  { path: '/news', label: '行业资讯' },
  { path: '/faq', label: '常见问题' },
  { path: '/about', label: '关于我们' },
  { path: '/contact', label: '联系我们' }
]
</script>

<template>
  <header class="site-header">
    <div class="container header-bar">
      <router-link to="/" class="logo" aria-label="雷普赛维 LABOR-SAVING 首页">
        <img src="/logo.svg" alt="雷普赛维 LABOR-SAVING 标志" width="38" height="38">
        <span class="name">雷普赛维<span style="color: var(--red);">·</span>LABOR-SAVING</span>
      </router-link>

      <nav class="nav" :class="{ open }" aria-label="主导航">
        <router-link
          v-for="item in navItems"
          :key="item.path"
          :to="item.path"
          :class="{ 'router-link-active': route.path === item.path || route.path.startsWith(item.path + '/') }"
        >{{ item.label }}</router-link>
        <router-link to="/contact" class="btn btn-red btn-small">请求报价</router-link>
      </nav>

      <button
        class="nav-toggle"
        aria-label="菜单"
        aria-expanded="open"
        aria-controls="main-nav"
        @click="open = !open"
      >☰</button>
    </div>
  </header>
</template>
