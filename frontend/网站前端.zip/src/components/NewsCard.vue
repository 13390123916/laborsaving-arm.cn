<script setup>
const props = defineProps({
  title: { type: String, required: true },
  summary: { type: String, required: true },
  category: { type: String, default: '' },
  publishedAt: { type: String, default: '' },
  views: { type: Number, default: 0 },
  to: { type: String, required: true }
})
</script>

<template>
  <router-link :to="to" class="news-card">
    <div class="news-meta">
      <span v-if="category" class="news-tag">{{ category }}</span>
      <span v-if="publishedAt" class="news-date">{{ publishedAt }}</span>
    </div>
    <h3>{{ title }}</h3>
    <p>{{ summary }}</p>
    <div class="news-footer">
      <span>阅读全文 →</span>
      <span v-if="views" class="news-views">{{ views }} 阅读</span>
    </div>
  </router-link>
</template>

<style scoped>
.news-card {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 26px;
  transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition);
}

.news-card:hover {
  transform: translateY(-4px);
  border-color: rgba(227, 28, 37, .35);
  box-shadow: var(--shadow);
}

.news-meta {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
}

.news-tag {
  padding: 4px 10px;
  border-radius: 999px;
  background: rgba(227, 28, 37, .1);
  color: var(--red);
  font-size: .75rem;
  font-weight: 600;
}

.news-date {
  color: var(--text-on-dark-muted);
  font-size: .85rem;
}

.news-card h3 {
  font-size: 1.15rem;
  color: #fff;
  margin-bottom: 10px;
  line-height: 1.4;
}

.news-card p {
  color: var(--text-on-dark-muted);
  font-size: .95rem;
  line-height: 1.7;
  flex: 1;
  margin-bottom: 18px;
}

.news-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: .9rem;
}

.news-footer span:first-child {
  color: var(--red);
  font-weight: 600;
}

.news-views {
  color: var(--text-on-dark-muted);
}

@media (max-width: 680px) {
  .news-card {
    padding: 20px;
  }
}
</style>
