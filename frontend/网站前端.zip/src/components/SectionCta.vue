<script setup>
const props = defineProps({
  title: { type: String, required: true },
  desc: { type: String, default: '' },
  ctaLabel: { type: String, default: '立即咨询' },
  ctaTo: { type: String, default: '/contact' },
  secondaryLabel: { type: String, default: '' },
  secondaryTo: { type: String, default: '' }
})
</script>

<template>
  <section class="section section-soft cta-section">
    <div class="container">
      <div class="cta-card">
        <div class="cta-content">
          <h2 class="h2">{{ title }}</h2>
          <p v-if="desc" class="lead">{{ desc }}</p>
        </div>
        <div class="cta-actions">
          <router-link :to="ctaTo" class="btn btn-red">{{ ctaLabel }}</router-link>
          <router-link v-if="secondaryLabel && secondaryTo" :to="secondaryTo" class="btn btn-ghost">{{ secondaryLabel }}</router-link>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.cta-section {
  padding: 60px 0;
}

.cta-card {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 32px;
  background: linear-gradient(135deg, rgba(227, 28, 37, .12), rgba(10, 10, 10, 0));
  border: 1px solid rgba(227, 28, 37, .2);
  border-radius: var(--radius-lg);
  padding: 40px;
}

.cta-content {
  flex: 1;
}

.cta-content h2 {
  margin-bottom: 10px;
}

.cta-actions {
  display: flex;
  gap: 14px;
  flex-shrink: 0;
}

@media (max-width: 680px) {
  .cta-card {
    flex-direction: column;
    align-items: flex-start;
    padding: 28px;
  }

  .cta-actions {
    width: 100%;
    flex-direction: column;
  }

  .cta-actions .btn {
    width: 100%;
  }
}
</style>
