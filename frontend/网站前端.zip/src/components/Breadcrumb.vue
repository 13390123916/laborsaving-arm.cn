<script setup>
import { computed } from 'vue'
import { useRoute } from 'vue-router'
import { useJsonLd } from '@/composables/useJsonLd'

const props = defineProps({
  items: { type: Array, default: () => [] }
})

const route = useRoute()

const schema = computed(() => {
  const listItems = [{ name: '首页', item: 'https://www.example.com/' }]
  for (const item of props.items) {
    listItems.push({ name: item.label, item: 'https://www.example.com' + (item.path || route.path) })
  }
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: listItems.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.item
    }))
  }
})

useJsonLd('jsonld-breadcrumb', schema)
</script>

<template>
  <nav class="breadcrumb" aria-label="面包屑">
    <router-link to="/">首页</router-link>
    <template v-for="(item, index) in items" :key="item.path || index">
      <span class="sep">/</span>
      <router-link v-if="item.path && item.path !== route.path" :to="item.path">{{ item.label }}</router-link>
      <span v-else>{{ item.label }}</span>
    </template>
  </nav>
</template>
