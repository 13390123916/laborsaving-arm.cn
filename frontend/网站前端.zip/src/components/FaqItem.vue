<script setup>
import { ref } from 'vue'

const props = defineProps({
  question: { type: String, required: true },
  shortAnswer: { type: String, required: true },
  detail: { type: String, default: '' },
  index: { type: Number, default: 0 }
})

const open = ref(false)
</script>

<template>
  <div class="faq-item" :class="{ open }">
    <button
      class="faq-question"
      :aria-expanded="open"
      @click="open = !open"
    >
      <span class="faq-q-text">
        <span class="faq-num">{{ String(index + 1).padStart(2, '0') }}</span>
        {{ props.question }}
      </span>
      <span class="faq-icon" aria-hidden="true">{{ open ? '−' : '+' }}</span>
    </button>
    <div class="faq-answer" :aria-hidden="!open">
      <div class="faq-answer-inner">
        <p class="short">{{ props.shortAnswer }}</p>
        <p v-if="props.detail" class="detail">{{ props.detail }}</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.faq-item {
  border-bottom: 1px solid var(--dark-border);
}

.faq-question {
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
  padding: 22px 0;
  text-align: left;
  color: #fff;
  font-size: 1.05rem;
  font-weight: 600;
  background: none;
  border: none;
}

.faq-q-text {
  display: flex;
  align-items: center;
  gap: 14px;
  line-height: 1.5;
}

.faq-num {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border-radius: 50%;
  background: var(--red-glow);
  color: var(--red);
  font-size: .85rem;
  font-weight: 700;
  flex-shrink: 0;
}

.faq-icon {
  width: 28px;
  height: 28px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  background: rgba(255, 255, 255, .08);
  color: #fff;
  font-size: 1.2rem;
  flex-shrink: 0;
  transition: background var(--transition), color var(--transition);
}

.faq-item.open .faq-icon {
  background: var(--red);
}

.faq-answer {
  display: grid;
  grid-template-rows: 0fr;
  transition: grid-template-rows .3s ease;
}

.faq-item.open .faq-answer {
  grid-template-rows: 1fr;
}

.faq-answer-inner {
  overflow: hidden;
  padding-bottom: 22px;
  padding-left: 50px;
}

.faq-answer-inner .short {
  color: var(--text-on-dark);
  font-size: 1rem;
  line-height: 1.7;
  margin-bottom: 10px;
}

.faq-answer-inner .detail {
  color: var(--text-on-dark-muted);
  font-size: .95rem;
  line-height: 1.75;
}

@media (max-width: 680px) {
  .faq-answer-inner {
    padding-left: 0;
  }
}
</style>
