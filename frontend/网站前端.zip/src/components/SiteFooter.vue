<script setup>
import { ref, onMounted } from 'vue'
import { useSiteStore } from '@/stores/site'

const site = useSiteStore()
const footerLinks = {
  products: [
    { path: '/products', label: '助力机械臂 / 平衡吊' },
    { path: '/products', label: '气动平衡器' },
    { path: '/products', label: '伺服助力臂' },
    { path: '/products', label: '全部产品' }
  ],
  franchise: [
    { path: '/franchise', label: '代理政策' },
    { path: '/franchise', label: '区域保护' },
    { path: '/franchise', label: '招商 FAQ' },
    { path: '/about', label: '企业资质' }
  ],
  contact: [
    { path: '/contact', label: '采购咨询' },
    { path: '/contact', label: '招商合作' },
    { path: '/about', label: '关于我们' },
    { path: '/news', label: '行业资讯' }
  ]
}

onMounted(() => site.fetchConfig())
</script>

<template>
  <footer class="site-footer">
    <div class="container">
      <div class="footer-grid">
        <div class="footer-brand">
          <router-link to="/" class="logo" aria-label="雷普赛维 LABOR-SAVING 首页">
            <img src="/logo.svg" alt="" width="38" height="38">
            <span class="name">雷普赛维<span style="color: var(--red);">·</span>LABOR-SAVING</span>
          </router-link>
          <p class="lead">雷普赛维（LABOR-SAVING）专注于助力机械臂、平衡吊、气动平衡器的研发与制造，为汽车、3C、家电、五金等行业提供省力搬运解决方案。</p>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">产品中心</h4>
          <div class="footer-links">
            <router-link v-for="link in footerLinks.products" :key="link.path + link.label" :to="link.path">{{ link.label }}</router-link>
          </div>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">全国招商</h4>
          <div class="footer-links">
            <router-link v-for="link in footerLinks.franchise" :key="link.path + link.label" :to="link.path">{{ link.label }}</router-link>
          </div>
        </div>

        <div class="footer-col">
          <h4 class="footer-title">联系我们</h4>
          <a :href="'tel:' + (site.config?.phone || '400-800-0000')" class="footer-phone">{{ site.config?.phone || '400-800-0000' }}</a>
          <div class="footer-links">
            <a :href="'mailto:' + (site.config?.email || 'bd@labor-saving.example')">{{ site.config?.email || 'bd@labor-saving.example' }}</a>
            <span>服务范围：{{ site.config?.service_range || '全国' }}</span>
          </div>
        </div>
      </div>

      <div class="footer-bottom">
        <span>© 2026 雷普赛维（LABOR-SAVING）智能装备 · 助力机械臂全国招商</span>
        <span>{{ site.config?.icp || 'ICP 备案号：待上线前补全' }}</span>
      </div>
    </div>
  </footer>
</template>
