<script setup>
const props = defineProps({
  title: { type: String, required: true },
  subtitle: { type: String, default: '' },
  desc: { type: String, required: true },
  to: { type: String, default: '' },
  highlights: { type: Array, default: () => [] }
})
</script>

<template>
  <router-link v-if="to" :to="to" class="product-card">
    <span v-if="subtitle" class="card-tag">{{ subtitle }}</span>
    <h3>{{ title }}</h3>
    <p>{{ desc }}</p>
    <ul class="highlights">
      <li v-for="h in highlights" :key="h">{{ h }}</li>
    </ul>
    <span class="card-link">了解详情 →</span>
  </router-link>
  <div v-else class="product-card">
    <span v-if="subtitle" class="card-tag">{{ subtitle }}</span>
    <h3>{{ title }}</h3>
    <p>{{ desc }}</p>
    <ul class="highlights">
      <li v-for="h in highlights" :key="h">{{ h }}</li>
    </ul>
  </div>
</template>

<style scoped>
.product-card {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 28px;
  transition: transform var(--transition), border-color var(--transition), box-shadow var(--transition);
}

.product-card:hover {
  transform: translateY(-4px);
  border-color: rgba(227, 28, 37, .35);
  box-shadow: var(--shadow);
}

.card-tag {
  align-self: flex-start;
  padding: 5px 12px;
  border-radius: 999px;
  background: rgba(227, 28, 37, .1);
  color: var(--red);
  font-size: .75rem;
  font-weight: 600;
  margin-bottom: 14px;
}

.product-card h3 {
  font-size: 1.3rem;
  color: #fff;
  margin-bottom: 10px;
}

.product-card p {
  color: var(--text-on-dark-muted);
  font-size: .95rem;
  line-height: 1.7;
  flex: 1;
  margin-bottom: 16px;
}

.highlights {
  margin-bottom: 18px;
}

.highlights li {
  position: relative;
  padding-left: 18px;
  color: #e5e5e5;
  font-size: .9rem;
  margin-bottom: 6px;
}

.highlights li::before {
  content: "";
  position: absolute;
  left: 0;
  top: 9px;
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--red);
}

.card-link {
  color: var(--red);
  font-weight: 600;
  font-size: .95rem;
}

@media (max-width: 680px) {
  .product-card {
    padding: 22px;
  }
}
</style>
