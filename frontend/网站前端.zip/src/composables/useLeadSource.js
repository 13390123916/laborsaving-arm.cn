export function useLeadSource() {
  function detect() {
    if (typeof document === 'undefined') return 'direct'
    const ref = document.referrer || ''
    const ua = navigator.userAgent || ''
    const url = new URL(location.href)

    const aiBots = ['GPTBot', 'ChatGPT', 'Perplexity', 'Claude', 'Bytespider']
    if (aiBots.some(b => ua.includes(b))) return 'ai'

    const searchEngines = [
      'baidu', 'google', 'bing', 'sogou', '360', 'so.com',
      'sm.cn', 'soso', 'yahoo', 'yandex', 'duckduckgo'
    ]
    if (searchEngines.some(s => ref.toLowerCase().includes(s))) return 'search'

    const utmSource = url.searchParams.get('utm_source')?.toLowerCase() || ''
    if (utmSource && (utmSource.includes('ai') || utmSource.includes('llm'))) return 'ai'
    if (utmSource && (utmSource.includes('search') || utmSource.includes('sem'))) return 'search'

    return ref ? 'other' : 'direct'
  }

  return { detect }
}
