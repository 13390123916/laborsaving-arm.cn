import { onMounted, onUnmounted, toValue } from 'vue'

export function useJsonLd(id, payload) {
  onMounted(() => {
    if (typeof document === 'undefined') return
    removeExisting(id)
    const value = toValue(payload)
    if (!value) return
    const script = document.createElement('script')
    script.type = 'application/ld+json'
    script.id = id
    script.textContent = JSON.stringify(value)
    document.head.appendChild(script)
  })

  onUnmounted(() => {
    removeExisting(id)
  })
}

function removeExisting(id) {
  const existing = document.getElementById(id)
  if (existing && existing.parentNode) {
    existing.parentNode.removeChild(existing)
  }
}
