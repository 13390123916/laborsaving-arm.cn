export function useTrack() {
  function pushBaidu(category, action, label) {
    try {
      if (window._hmt && typeof window._hmt.push === 'function') {
        window._hmt.push(['_trackEvent', category, action, label])
      }
    } catch (e) { /* ignore */ }
  }

  function pushGtm(eventName, payload = {}) {
    try {
      window.dataLayer = window.dataLayer || []
      window.dataLayer.push({ event: eventName, ...payload })
    } catch (e) { /* ignore */ }
  }

  function trackLeadSubmit(leadType, leadSource) {
    pushBaidu('招商线索', '提交', leadType)
    pushGtm('lead_submit', { leadType, leadSource })
  }

  return { pushBaidu, pushGtm, trackLeadSubmit }
}
