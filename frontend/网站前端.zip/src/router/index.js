import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home.vue'),
    meta: {
      title: '雷普赛维机械臂厂家_全国招商代理加盟_LABOR-SAVING',
      keywords: '机械臂厂家,机械臂招商,机械臂代理,工业机器人,LABOR-SAVING',
      description: '雷普赛维（LABOR-SAVING）全国招募机械臂区域代理，提供产品培训、区域保护、售后支持，欢迎咨询加盟政策。'
    }
  },
  {
    path: '/products',
    name: 'Products',
    component: () => import('@/views/Products.vue'),
    meta: {
      title: '三大助力机械臂系列_厂家直供_雷普赛维',
      keywords: '助力机械臂,平衡吊,气动平衡器,伺服助力臂,机械臂厂家',
      description: '雷普赛维提供助力机械臂、平衡吊、气动平衡器、伺服助力臂系列产品，适用于上下料、装配、搬运场景，厂家直供，支持代理。'
    }
  },
  {
    path: '/products/:slug',
    name: 'ProductDetail',
    component: () => import('@/views/ProductDetail.vue'),
    meta: {
      title: '产品详情_雷普赛维机械臂厂家',
      keywords: '机械臂参数,助力机械臂,工业机械臂',
      description: '雷普赛维机械臂产品详细参数与适用场景，厂家直供，支持全国招商代理。'
    }
  },
  {
    path: '/franchise',
    name: 'Franchise',
    component: () => import('@/views/Franchise.vue'),
    meta: {
      title: '机械臂全国招商_区域代理招募_雷普赛维扶持政策',
      keywords: '机械臂招商,机械臂代理加盟,区域代理,机械臂经销商,招商政策,代理条件,加盟流程',
      description: '雷普赛维面向全国招募机械臂经销商，享区域保护、价格政策、培训扶持，了解代理条件与流程。'
    }
  },
  {
    path: '/news',
    name: 'NewsList',
    component: () => import('@/views/NewsList.vue'),
    meta: {
      title: '行业资讯_机械臂招商应用与选型_雷普赛维',
      keywords: '机械臂行业资讯,协作机器人应用,机械臂选型,工业自动化',
      description: '雷普赛维机械臂行业资讯、应用案例与选型科普，赋能全国经销商与终端客户。'
    }
  },
  {
    path: '/news/:slug',
    name: 'NewsDetail',
    component: () => import('@/views/NewsDetail.vue'),
    meta: {
      title: '资讯详情_雷普赛维机械臂行业资讯',
      keywords: '机械臂资讯,工业自动化,雷普赛维',
      description: '雷普赛维机械臂行业洞察与招商赋能资讯。'
    }
  },
  {
    path: '/faq',
    name: 'Faq',
    component: () => import('@/views/Faq.vue'),
    meta: {
      title: '机械臂招商代理常见问题_雷普赛维FAQ',
      keywords: '机械臂FAQ,机械臂代理问答,招商政策疑问,采购选型疑问',
      description: '雷普赛维整理机械臂招商、代理、选型、售后高频问答，解答代理政策与采购疑虑。'
    }
  },
  {
    path: '/about',
    name: 'About',
    component: () => import('@/views/About.vue'),
    meta: {
      title: '关于雷普赛维_LABOR-SAVING企业简介与资质',
      keywords: '雷普赛维,企业简介,机械臂厂家资质,助力机械臂',
      description: '雷普赛维（LABOR-SAVING）企业实体介绍，含成立时间、经营规模、资质实力与全国服务范围。'
    }
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('@/views/Contact.vue'),
    meta: {
      title: '联系我们_采购咨询与招商合作_雷普赛维',
      keywords: '机械臂采购咨询,机械臂厂家联系方式,雷普赛维招商',
      description: '联系雷普赛维（LABOR-SAVING），获取机械臂采购咨询、招商代理合作与技术支持。'
    }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue'),
    meta: {
      title: '页面未找到_雷普赛维',
      keywords: '雷普赛维',
      description: '抱歉，您访问的页面不存在，返回雷普赛维官网首页。'
    }
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) return savedPosition
    if (to.hash) return { el: to.hash, behavior: 'smooth' }
    return { top: 0, behavior: 'smooth' }
  }
})

// 百度自动链接提交（路由切换时）
router.afterEach((to) => {
  if (typeof window === 'undefined') return
  try {
    if (location.hostname === 'localhost' || location.hostname === '127.0.0.1') return
    if (!window.__bdPushLoaded) {
      const bp = document.createElement('script')
      bp.src = 'https://zz.bdstatic.com/linksubmit/push.js'
      bp.async = true
      document.body.appendChild(bp)
      window.__bdPushLoaded = true
    }
    if (window._hmt && window._hmt.push) {
      window._hmt.push(['_trackPageview', to.fullPath])
    }
  } catch (e) {
    // 静默失败，不影响用户
  }
})

export default router
