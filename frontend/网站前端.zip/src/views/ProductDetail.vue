<script setup>
import { computed } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import { useJsonLd } from '@/composables/useJsonLd'

const route = useRoute()
const slug = route.params.slug

const products = {
  'balance-arm': {
    title: '助力机械臂 / 平衡吊',
    desc: '通过气动或伺服平衡实现「零重力搬运」，操作员只需施加小力即可托举数十至数百公斤工件，沿任意方向平移、旋转、升降，无需编程即可上手。',
    specs: { '负载范围': '50-300kg', '工作半径': '1500-3500mm', '提升方式': '气动/伺服', '控制方式': '手动随动', '典型应用': '上下料、装配、移栽' },
    keywords: '助力机械臂,平衡吊,零重力搬运',
    description: '雷普赛维助力机械臂/平衡吊，零重力搬运，负载 50-300kg，适用于上下料、装配、移栽。'
  },
  'pneumatic-balancer': {
    title: '气动平衡器',
    desc: '纯气动平衡方案，结构简洁、维护成本低，对气源友好。适合负载稳定、节拍中等的常规搬运与定位场景。',
    specs: { '负载范围': '50-200kg', '工作半径': '1500-3000mm', '驱动方式': '纯气动', '控制方式': '手动随动', '典型应用': '装配、包装、搬运' },
    keywords: '气动平衡器,机械臂厂家,省力搬运',
    description: '雷普赛维气动平衡器，结构简洁、维护成本低，负载 50-200kg，适合常规搬运与定位。'
  },
  'servo-assist': {
    title: '伺服助力臂',
    desc: '支持力控反馈、位置记忆与数据上云，更易接入智能工厂。适合高精度定位与数字化管理需求。',
    specs: { '负载范围': '50-600kg', '工作半径': '2000-4000mm', '驱动方式': '伺服电机', '控制方式': '力控/位置记忆', '典型应用': '精密装配、焊接、上下料' },
    keywords: '伺服助力臂,智能工厂,力控机械臂',
    description: '雷普赛维伺服助力臂，支持力控反馈与位置记忆，负载 50-600kg，适配智能工厂。'
  }
}

const product = computed(() => products[slug] || products['balance-arm'])

useHead({
  title: `${product.value.title}_厂家直供_雷普赛维`,
  meta: [
    { name: 'keywords', content: product.value.keywords },
    { name: 'description', content: product.value.description }
  ]
})

useJsonLd('jsonld-product', {
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: product.value.title,
  image: 'https://www.example.com/logo.jpg',
  description: product.value.description,
  brand: { '@type': 'Brand', name: '雷普赛维（LABOR-SAVING）' },
  manufacturer: { '@type': 'Organization', name: '雷普赛维（LABOR-SAVING）' },
  offers: {
    '@type': 'Offer',
    url: `https://www.example.com/products/${slug}`,
    availability: 'https://schema.org/InStock',
    seller: { '@type': 'Organization', name: '雷普赛维（LABOR-SAVING）' }
  },
  additionalProperty: Object.entries(product.value.specs).map(([name, value]) => ({
    '@type': 'PropertyValue', name, value
  }))
})
</script>

<template>
  <div class="product-detail-page">
    <div class="container">
      <Breadcrumb :items="[
        { path: '/products', label: '产品中心' },
        { path: route.path, label: product.title }
      ]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <span class="eyebrow">产品详情</span>
        <h1 class="h2">{{ product.title }}</h1>
        <p class="lead" style="margin-top: 14px; margin-bottom: 28px;">{{ product.desc }}</p>

        <div class="card">
          <h3 class="h3" style="margin-bottom: 20px;">技术参数</h3>
          <table class="spec-table">
            <tbody>
              <tr v-for="(value, key) in product.specs" :key="key">
                <th>{{ key }}</th>
                <td>{{ value }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="cta-row" style="margin-top: 28px;">
          <router-link to="/contact" class="btn btn-red">采购咨询</router-link>
          <router-link to="/products" class="btn btn-ghost">返回产品列表</router-link>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.cta-row {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}
@media (max-width: 680px) {
  .cta-row .btn {
    flex: 1 1 100%;
  }
}
</style>
