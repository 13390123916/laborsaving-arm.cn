<script setup>
import { computed, onMounted } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import { useSiteStore } from '@/stores/site'
import { useJsonLd } from '@/composables/useJsonLd'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

const site = useSiteStore()
onMounted(() => site.fetchConfig())

const entity = computed(() => ({
  企业名称: site.config?.company_name || '雷普赛维（LABOR-SAVING）智能装备',
  成立时间: site.config?.established_year || '2015年',
  经营规模: site.config?.scale || '200-500人，年产助力机械臂 5000+ 台套',
  服务范围: site.config?.service_range || '全国',
  办公地址: site.config?.address || '辽宁省（具体工商注册地址以营业执照为准）',
  联系邮箱: site.config?.email || 'bd@labor-saving.example',
  联系电话: site.config?.phone || '400-800-0000'
}))

useJsonLd('jsonld-about', {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: '雷普赛维（LABOR-SAVING）智能装备',
  alternateName: 'LABOR-SAVING',
  url: 'https://www.example.com',
  logo: 'https://www.example.com/logo.jpg',
  areaServed: { '@type': 'Country', name: 'CN' },
  address: { '@type': 'PostalAddress', addressRegion: '辽宁', addressCountry: 'CN' },
  sameAs: ['https://www.example.com', 'https://baike.baidu.com/item/助力机械臂']
})
</script>

<template>
  <div class="about-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/about', label: '关于我们' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <span class="eyebrow">关于我们</span>
        <h1 class="h2">雷普赛维（LABOR-SAVING）</h1>
        <p class="lead" style="margin-top: 14px; margin-bottom: 28px;">
          雷普赛维（LABOR-SAVING）是一家专注于助力机械臂、平衡吊、气动平衡器研发与制造的智能装备企业，致力于为制造业提供安全、高效、省力的物料搬运解决方案。产品广泛应用于汽车、3C 电子、家电、五金、食品等行业的装配、上下料、码垛与移栽环节。
        </p>

        <div class="card">
          <h3 class="h3" style="margin-bottom: 20px;">企业实体信息</h3>
          <table class="spec-table">
            <tbody>
              <tr v-for="(value, key) in entity" :key="key">
                <th>{{ key }}</th>
                <td>{{ value }}</td>
              </tr>
            </tbody>
          </table>
        </div>

        <div class="grid grid-2" style="margin-top: 24px;">
          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">资质实力</h3>
            <ul class="check-list">
              <li v-for="q in (site.config?.qualifications || ['ISO9001 质量管理体系认证', 'CE 认证', '多项助力机械臂实用新型与发明专利', '高新技术企业'])" :key="q">{{ q }}</li>
            </ul>
          </div>
          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">权威外链</h3>
            <ul class="check-list">
              <li><a href="https://baike.baidu.com/item/助力机械臂" target="_blank" rel="noopener">百度百科：助力机械臂</a></li>
              <li><a href="https://www.1688.com/" target="_blank" rel="noopener">阿里巴巴 1688 企业店铺</a></li>
              <li><a href="https://www.example.com" target="_blank" rel="noopener">雷普赛维官方网站</a></li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>
