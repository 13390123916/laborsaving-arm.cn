<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import NewsCard from '@/components/NewsCard.vue'
import { newsApi } from '@/api/content'
import { useJsonLd } from '@/composables/useJsonLd'
import fallbackData from '@/data/fallback.json'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

const categories = ref(fallbackData.newsCategories)
const newsList = ref(fallbackData.newsList)
const currentCategory = ref(route.query.category || '')

watch(() => route.query.category, (val) => { currentCategory.value = val || '' })

async function loadData() {
  try { categories.value = await newsApi.categories() } catch {}
  try { newsList.value = await newsApi.list({ category: currentCategory.value }) } catch {}
}

onMounted(loadData)

const filteredNews = computed(() => newsList.value?.results || [])

useJsonLd('jsonld-news', {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: '雷普赛维（LABOR-SAVING）智能装备',
  url: 'https://www.example.com',
  logo: 'https://www.example.com/logo.jpg'
})
</script>

<template>
  <div class="news-list-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/news', label: '行业资讯' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">行业资讯</span>
          <h1 class="h2">机械臂行业洞察与招商赋能</h1>
          <p class="lead">招商政策解读、行业应用方案、选型科普与企业动态，助力经销商与终端客户科学决策。</p>
        </div>

        <div class="filter-bar">
          <router-link
            to="/news"
            class="filter-pill"
            :class="{ active: !currentCategory }"
          >全部</router-link>
          <router-link
            v-for="cat in categories"
            :key="cat.id"
            :to="`/news?category=${cat.slug}`"
            class="filter-pill"
            :class="{ active: currentCategory === cat.slug }"
          >{{ cat.name }}</router-link>
        </div>

        <div class="grid grid-3">
          <NewsCard
            v-for="item in filteredNews"
            :key="item.id"
            :title="item.title"
            :summary="item.summary"
            :category="item.category_name"
            :published-at="item.published_at"
            :views="item.views"
            :to="`/news/${item.slug}`"
          />
        </div>

        <div v-if="!filteredNews.length" class="empty-state">
          暂无资讯内容
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.filter-bar {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  margin-bottom: 32px;
}

.filter-pill {
  padding: 8px 18px;
  border-radius: 999px;
  border: 1px solid var(--dark-border);
  background: var(--dark-card);
  color: var(--text-on-dark-muted);
  font-size: .9rem;
  transition: all var(--transition);
}

.filter-pill:hover,
.filter-pill.active {
  background: var(--red);
  border-color: var(--red);
  color: #fff;
}

.empty-state {
  text-align: center;
  padding: 48px 0;
  color: var(--text-on-dark-muted);
  border: 1px dashed var(--dark-border);
  border-radius: var(--radius-lg);
}
</style>
