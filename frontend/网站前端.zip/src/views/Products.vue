<script setup>
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import ProductCard from '@/components/ProductCard.vue'
import { useJsonLd } from '@/composables/useJsonLd'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

const products = [
  {
    slug: 'balance-arm',
    title: '助力机械臂 / 平衡吊',
    subtitle: '传统省力方案',
    desc: '通过气动或伺服平衡实现「零重力搬运」，操作员只需施加小力即可托举数十至数百公斤工件，沿任意方向平移、旋转、升降，无需编程即可上手。',
    highlights: ['零重力悬浮', '多自由度搬运', '操作直观', '维护成本低']
  },
  {
    slug: 'pneumatic-balancer',
    title: '气动平衡器',
    subtitle: '经济可靠',
    desc: '纯气动平衡方案，结构简洁、维护成本低，对气源友好。适合负载稳定、节拍中等的常规搬运与定位场景。',
    highlights: ['结构简单', '维护方便', '成本可控', '响应快速']
  },
  {
    slug: 'servo-assist',
    title: '伺服助力臂',
    subtitle: '智能力控',
    desc: '支持力控反馈、位置记忆与数据上云，更易接入智能工厂。适合高精度定位与数字化管理需求。',
    highlights: ['力控反馈', '位置记忆', '可上云', '高精度定位']
  }
]

useJsonLd('jsonld-products', {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: '雷普赛维（LABOR-SAVING）智能装备',
  url: 'https://www.example.com',
  logo: 'https://www.example.com/logo.jpg',
  areaServed: { '@type': 'Country', name: 'CN' }
})
</script>

<template>
  <div class="products-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/products', label: '产品中心' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">产品中心</span>
          <h1 class="h2">三大助力机械臂系列</h1>
          <p class="lead">覆盖 50-600kg 负载区间，适配上下料、装配、搬运、焊接等多种工业场景。</p>
        </div>

        <div class="grid grid-3">
          <ProductCard
            v-for="p in products"
            :key="p.slug"
            :title="p.title"
            :subtitle="p.subtitle"
            :desc="p.desc"
            :to="`/products/${p.slug}`"
            :highlights="p.highlights"
          />
        </div>
      </div>
    </section>
  </div>
</template>
