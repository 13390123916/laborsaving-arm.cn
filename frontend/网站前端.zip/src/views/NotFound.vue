<script setup>
import { useHead } from '@vueuse/head'

useHead({
  title: '页面未找到_雷普赛维',
  meta: [
    { name: 'keywords', content: '雷普赛维' },
    { name: 'description', content: '抱歉，您访问的页面不存在，返回雷普赛维官网首页。' }
  ]
})
</script>

<template>
  <section class="section section-dark not-found">
    <div class="container text-center">
      <div class="h1" style="font-size: 6rem; color: var(--red); line-height: 1;">404</div>
      <h1 class="h2" style="margin: 18px 0 12px;">页面未找到</h1>
      <p class="lead" style="margin: 0 auto 28px;">抱歉，您访问的页面不存在或已被移除。</p>
      <div class="actions">
        <router-link to="/" class="btn btn-red">返回首页</router-link>
        <router-link to="/contact" class="btn btn-ghost">联系我们</router-link>
      </div>
    </div>
  </section>
</template>

<style scoped>
.not-found {
  min-height: 60vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.actions {
  display: flex;
  gap: 16px;
  justify-content: center;
  flex-wrap: wrap;
}

@media (max-width: 680px) {
  .actions .btn {
    flex: 1 1 100%;
  }
}
</style>
