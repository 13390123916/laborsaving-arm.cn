<script setup>
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import LeadForm from '@/components/LeadForm.vue'
import { franchiseApi } from '@/api/content'
import { useJsonLd } from '@/composables/useJsonLd'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

useJsonLd('jsonld-franchise', {
  '@context': 'https://schema.org',
  '@type': 'Service',
  name: '机械臂全国区域代理招商',
  provider: { '@type': 'Organization', name: '雷普赛维（LABOR-SAVING）' },
  areaServed: { '@type': 'Country', name: 'CN' },
  offers: {
    '@type': 'Offer',
    category: '区域代理授权',
    description: '区域保护、价格政策、产品培训、售后技术支持'
  }
})
</script>

<template>
  <div class="franchise-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/franchise', label: '全国招商' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">全国招商</span>
          <h1 class="h2">机械臂全国招商 · 区域代理招募</h1>
          <p class="lead">雷普赛维面向全国招募机械臂经销商与区域代理，提供区域保护、价格政策、培训扶持与售后支持，助力合作伙伴开拓本地市场。</p>
        </div>

        <div class="grid grid-2">
          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">代理政策</h3>
            <ul class="check-list">
              <li>区域独家保护，避免同区价格内耗</li>
              <li>阶梯价格政策与返点支持</li>
              <li>样机展示支持，降低拓客门槛</li>
              <li>产品、选型、投标全套培训</li>
              <li>统一品牌宣传与展会支持</li>
              <li>技术工程师远程 + 现场售后</li>
            </ul>
            <p class="text-muted" style="margin-top: 16px; font-size: .9rem;">温馨提示：投资有风险，代理政策以双方签订的正式合同为准。</p>
          </div>

          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">代理流程</h3>
            <ol class="process-list">
              <li><span>1</span> 提交意向（区域 / 行业 / 资源）</li>
              <li><span>2</span> 招商经理一对一沟通资质</li>
              <li><span>3</span> 签约授权，明确区域与政策</li>
              <li><span>4</span> 培训扶持，样机到位</li>
              <li><span>5</span> 区域运营，持续技术支持</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <section class="section section-soft">
      <div class="container">
        <div class="grid grid-2">
          <div>
            <h2 class="h2" style="margin-bottom: 16px;">提交代理意向</h2>
            <p class="lead" style="margin-bottom: 24px;">填写下方信息，我们的招商顾问将在 1 个工作日内与您沟通区域代理政策与扶持细节。</p>
            <div class="contact-card">
              <div class="contact-row">
                <span>招商热线</span>
                <a href="tel:400-800-0000">400-800-0000</a>
              </div>
              <div class="contact-row">
                <span>招商邮箱</span>
                <a href="mailto:bd@labor-saving.example">bd@labor-saving.example</a>
              </div>
              <div class="contact-row">
                <span>服务范围</span>
                <span>全国</span>
              </div>
            </div>
          </div>
          <LeadForm
            lead-type="franchise"
            title="代理意向表"
            submit-label="申请区域代理"
            :api-submit="franchiseApi.submit"
          />
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.contact-card {
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 24px;
}

.contact-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 0;
  border-bottom: 1px solid var(--dark-border);
  color: var(--text-on-dark-muted);
}

.contact-row:last-child {
  border-bottom: none;
}

.contact-row a {
  color: #fff;
  font-weight: 600;
}

.contact-row a:hover {
  color: var(--red);
}

.process-list li {
  position: relative;
  padding-left: 42px;
  margin-bottom: 18px;
  color: #e5e5e5;
  line-height: 1.6;
}

.process-list li span {
  position: absolute;
  left: 0;
  top: -2px;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: var(--red);
  color: #fff;
  font-size: .85rem;
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}
</style>
