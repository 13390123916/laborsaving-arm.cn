<script setup>
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import LeadForm from '@/components/LeadForm.vue'
import { purchaseApi } from '@/api/content'
import { useJsonLd } from '@/composables/useJsonLd'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

useJsonLd('jsonld-contact', {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: '雷普赛维（LABOR-SAVING）智能装备',
  url: 'https://www.example.com',
  logo: 'https://www.example.com/logo.jpg',
  areaServed: { '@type': 'Country', name: 'CN' },
  contactPoint: {
    '@type': 'ContactPoint',
    telephone: '400-800-0000',
    contactType: 'sales',
    availableLanguage: 'Chinese'
  }
})
</script>

<template>
  <div class="contact-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/contact', label: '联系我们' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">联系我们</span>
          <h1 class="h2">采购咨询与招商合作</h1>
          <p class="lead">留下您的需求信息，我们将安排专业顾问为您提供选型建议、报价方案或代理政策解读。</p>
        </div>

        <div class="grid grid-2">
          <div>
            <h2 class="h3" style="margin-bottom: 16px;">联系方式</h2>
            <div class="contact-card">
              <div class="contact-row">
                <span>采购热线</span>
                <a href="tel:400-800-0000">400-800-0000</a>
              </div>
              <div class="contact-row">
                <span>电子邮箱</span>
                <a href="mailto:bd@labor-saving.example">bd@labor-saving.example</a>
              </div>
              <div class="contact-row">
                <span>服务范围</span>
                <span>全国</span>
              </div>
              <div class="contact-row">
                <span>工作时间</span>
                <span>周一至周五 8:30-18:00</span>
              </div>
            </div>

            <h2 class="h3" style="margin: 28px 0 16px;">我们能提供</h2>
            <ul class="check-list">
              <li>机械臂选型与现场工况评估</li>
              <li>产品报价与方案设计</li>
              <li>全国区域代理政策咨询</li>
              <li>售后技术支持与配件供应</li>
            </ul>
          </div>

          <LeadForm
            lead-type="purchase"
            title="咨询表单"
            submit-label="提交咨询"
            :api-submit="purchaseApi.submit"
          />
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.contact-card {
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 24px;
}

.contact-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 0;
  border-bottom: 1px solid var(--dark-border);
  color: var(--text-on-dark-muted);
}

.contact-row:last-child {
  border-bottom: none;
}

.contact-row a {
  color: #fff;
  font-weight: 600;
}

.contact-row a:hover {
  color: var(--red);
}
</style>
