<script setup>
import { ref, computed, onMounted } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import FaqItem from '@/components/FaqItem.vue'
import { faqApi } from '@/api/content'
import { useJsonLd } from '@/composables/useJsonLd'
import fallbackData from '@/data/fallback.json'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description }
  ]
})

const faqList = ref(fallbackData.faqList)

onMounted(async () => {
  try {
    faqList.value = await faqApi.list()
  } catch {}
})

const faqPageSchema = computed(() => ({
  '@context': 'https://schema.org',
  '@type': 'FAQPage',
  mainEntity: (faqList.value?.results || []).map(item => ({
    '@type': 'Question',
    name: item.question,
    acceptedAnswer: {
      '@type': 'Answer',
      text: `${item.short_answer} ${item.detail}`
    }
  }))
}))

useJsonLd('jsonld-faq', faqPageSchema)
</script>

<template>
  <div class="faq-page">
    <div class="container">
      <Breadcrumb :items="[{ path: '/faq', label: '常见问题' }]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">常见问题</span>
          <h1 class="h2">机械臂招商代理常见问题</h1>
          <p class="lead">我们整理了招商政策、代理支持、选型、售后等高频问答，帮助您快速了解雷普赛维。</p>
        </div>

        <div class="faq-list">
          <FaqItem
            v-for="(item, index) in (faqList?.results || [])"
            :key="item.id"
            :index="index"
            :question="item.question"
            :short-answer="item.short_answer"
            :detail="item.detail"
          />
        </div>

        <div class="cta-box" style="margin-top: 40px;">
          <h3 class="h3" style="margin-bottom: 8px;">还有疑问？</h3>
          <p class="text-muted" style="margin-bottom: 18px;">欢迎联系我们的招商顾问，获取一对一政策解读。</p>
          <router-link to="/contact" class="btn btn-red">联系我们</router-link>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.faq-list {
  border-top: 1px solid var(--dark-border);
}

.cta-box {
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 32px;
  text-align: center;
}

@media (max-width: 680px) {
  .cta-box {
    padding: 24px;
  }
}
</style>
