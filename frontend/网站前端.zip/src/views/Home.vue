<script setup>
import { computed, onMounted, ref } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute } from 'vue-router'
import { useSiteStore } from '@/stores/site'
import { useJsonLd } from '@/composables/useJsonLd'
import { faqApi, newsApi } from '@/api/content'
import ProductCard from '@/components/ProductCard.vue'
import FaqItem from '@/components/FaqItem.vue'
import NewsCard from '@/components/NewsCard.vue'
import SectionCta from '@/components/SectionCta.vue'
import fallbackData from '@/data/fallback.json'

const route = useRoute()
const meta = route.meta
useHead({
  title: meta.title,
  meta: [
    { name: 'keywords', content: meta.keywords },
    { name: 'description', content: meta.description },
    { rel: 'canonical', href: 'https://www.example.com/' }
  ]
})

const site = useSiteStore()

const faqList = ref(fallbackData.faqList)
const newsList = ref(fallbackData.newsList)

const faqs = computed(() => faqList.value?.results?.slice(0, 5) || [])
const news = computed(() => newsList.value?.results?.slice(0, 3) || [])

onMounted(async () => {
  site.fetchConfig()
  try { faqList.value = await faqApi.list() } catch {}
  try { newsList.value = await newsApi.list() } catch {}
})

useJsonLd('jsonld-home', {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: '雷普赛维（LABOR-SAVING）智能装备',
  alternateName: 'LABOR-SAVING',
  url: 'https://www.example.com',
  logo: 'https://www.example.com/logo.jpg',
  areaServed: { '@type': 'Country', name: 'CN' },
  address: { '@type': 'PostalAddress', addressRegion: '辽宁', addressCountry: 'CN' },
  sameAs: ['https://www.example.com', 'https://baike.baidu.com/item/助力机械臂']
})
</script>

<template>
  <div class="home-page">
    <!-- Hero -->
    <section class="hero">
      <div class="container">
        <span class="eyebrow">全国招商 · 区域代理招募</span>
        <h1 class="h1">
          雷普赛维 <span class="text-red">LABOR-SAVING</span><br>
          助力机械臂 · 让搬运更省力
        </h1>
        <p class="lead hero-desc">
          雷普赛维（LABOR-SAVING）是一家专注于助力机械臂、平衡吊、气动平衡器研发与制造的智能装备企业，致力于为制造业提供安全、高效、省力的物料搬运解决方案。产品广泛应用于汽车、3C 电子、家电、五金、食品等行业的装配、上下料、码垛与移栽环节。
        </p>
        <div class="hero-actions">
          <router-link to="/franchise" class="btn btn-red">了解招商政策</router-link>
          <router-link to="/products" class="btn btn-ghost">查看产品系列</router-link>
        </div>
      </div>
    </section>

    <!-- Stats -->
    <section class="stats-band">
      <div class="container stats-grid">
        <div class="stat">
          <div class="stat-num">5000+</div>
          <div class="stat-label">台套 / 年产能</div>
        </div>
        <div class="stat">
          <div class="stat-num">50-600<span>kg</span></div>
          <div class="stat-label">负载覆盖区间</div>
        </div>
        <div class="stat">
          <div class="stat-num">全国</div>
          <div class="stat-label">区域代理保护</div>
        </div>
      </div>
    </section>

    <!-- Feature band -->
    <section class="feature-band">
      <div class="container feature-grid">
        <div class="feature"><span class="feature-icon">✓</span> 区域保护</div>
        <div class="feature"><span class="feature-icon">✓</span> 培训扶持</div>
        <div class="feature"><span class="feature-icon">✓</span> 售后支持</div>
        <div class="feature"><span class="feature-icon">✓</span> 全国服务</div>
      </div>
    </section>

    <!-- Products -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">产品系列</span>
          <h2 class="h2">三大助力机械臂系列，覆盖多场景省力搬运</h2>
          <p class="lead">从纯气动到伺服力控，提供与人机协同匹配的搬运方案，即装即用、无需编程。</p>
        </div>
        <div class="grid grid-3">
          <ProductCard
            title="助力机械臂 / 平衡吊"
            subtitle="传统省力方案"
            desc="通过气动或伺服平衡实现「零重力搬运」，操作员只需施加小力即可托举数十至数百公斤工件，沿任意方向平移、旋转、升降，无需编程即可上手。"
            to="/products/balance-arm"
            :highlights="['零重力悬浮', '多自由度搬运', '操作直观']"
          />
          <ProductCard
            title="气动平衡器"
            subtitle="经济可靠"
            desc="纯气动平衡方案，结构简洁、维护成本低，对气源友好。适合负载稳定、节拍中等的常规搬运与定位场景。"
            to="/products/pneumatic-balancer"
            :highlights="['结构简单', '维护方便', '成本可控']"
          />
          <ProductCard
            title="伺服助力臂"
            subtitle="智能力控"
            desc="支持力控反馈、位置记忆与数据上云，更易接入智能工厂。适合高精度定位与数字化管理需求。"
            to="/products/servo-assist"
            :highlights="['力控反馈', '位置记忆', '可上云']"
          />
        </div>
      </div>
    </section>

    <!-- Franchise -->
    <section class="section section-soft">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">全国招商</span>
          <h2 class="h2">与雷普赛维一起，做区域机械臂代理</h2>
        </div>
        <div class="grid grid-2">
          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">代理优势</h3>
            <ul class="check-list">
              <li>区域独家保护，避免同区价格内耗</li>
              <li>阶梯价格政策与返点支持</li>
              <li>样机展示支持，降低拓客门槛</li>
              <li>产品、选型、投标全套培训</li>
              <li>统一品牌宣传与展会支持</li>
              <li>技术工程师远程 + 现场售后</li>
            </ul>
            <router-link to="/franchise" class="btn btn-red" style="margin-top: 10px;">申请区域代理</router-link>
          </div>
          <div class="card">
            <h3 class="h3" style="margin-bottom: 18px;">代理流程</h3>
            <ol class="process-list">
              <li><span>1</span> 提交意向（区域 / 行业 / 资源）</li>
              <li><span>2</span> 招商经理一对一沟通资质</li>
              <li><span>3</span> 签约授权，明确区域与政策</li>
              <li><span>4</span> 培训扶持，样机到位</li>
              <li><span>5</span> 区域运营，持续技术支持</li>
            </ol>
          </div>
        </div>
      </div>
    </section>

    <!-- FAQ preview -->
    <section class="section section-dark">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">常见问题</span>
          <h2 class="h2">代理与选型，先搞清楚这几件事</h2>
        </div>
        <div class="faq-preview">
          <FaqItem
            v-for="(item, index) in faqs"
            :key="item.id"
            :index="index"
            :question="item.question"
            :short-answer="item.short_answer"
            :detail="item.detail"
          />
        </div>
        <div class="text-center" style="margin-top: 28px;">
          <router-link to="/faq" class="btn btn-ghost">查看全部 FAQ</router-link>
        </div>
      </div>
    </section>

    <!-- News -->
    <section class="section section-soft">
      <div class="container">
        <div class="section-header">
          <span class="eyebrow">行业资讯</span>
          <h2 class="h2">机械臂行业洞察与招商赋能</h2>
        </div>
        <div class="grid grid-3">
          <NewsCard
            v-for="item in news"
            :key="item.id"
            :title="item.title"
            :summary="item.summary"
            :category="item.category_name"
            :published-at="item.published_at"
            :views="item.views"
            :to="`/news/${item.slug}`"
          />
        </div>
        <div class="text-center" style="margin-top: 28px;">
          <router-link to="/news" class="btn btn-ghost">更多资讯</router-link>
        </div>
      </div>
    </section>

    <SectionCta
      title="立即开启机械臂区域代理合作"
      desc="留下您的联系方式，招商顾问将在 1 个工作日内与您沟通代理政策与区域保护细节。"
      cta-label="提交代理意向"
      cta-to="/franchise"
      secondary-label="采购咨询"
      secondary-to="/contact"
    />
  </div>
</template>

<style scoped>
.hero {
  position: relative;
  padding: 120px 0 90px;
  background: radial-gradient(circle at 70% 30%, rgba(227, 28, 37, .12), transparent 45%), var(--dark);
  overflow: hidden;
}

.hero .container {
  position: relative;
  z-index: 1;
}

.hero .h1 {
  max-width: 820px;
  margin-bottom: 22px;
}

.hero-desc {
  max-width: 720px;
  margin-bottom: 32px;
}

.hero-actions {
  display: flex;
  gap: 16px;
  flex-wrap: wrap;
}

.stats-band {
  padding: 40px 0;
  background: var(--dark-soft);
  border-bottom: 1px solid var(--dark-border);
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
}

.stat {
  text-align: center;
  padding: 14px 0;
}

.stat-num {
  font-size: clamp(2rem, 5vw, 3rem);
  font-weight: 800;
  color: #fff;
  line-height: 1.1;
}

.stat-num span {
  font-size: 1.2rem;
  font-weight: 600;
  margin-left: 2px;
}

.stat-label {
  margin-top: 6px;
  color: var(--text-on-dark-muted);
  font-size: .95rem;
}

.feature-band {
  background: var(--red);
  padding: 22px 0;
}

.feature-grid {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 16px;
}

.feature {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  color: #fff;
  font-weight: 600;
  font-size: 1rem;
}

.feature-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 22px;
  height: 22px;
  border-radius: 50%;
  background: rgba(255, 255, 255, .2);
  font-size: .8rem;
}

.process-list li {
  position: relative;
  padding-left: 42px;
  margin-bottom: 18px;
  color: #e5e5e5;
  line-height: 1.6;
}

.process-list li span {
  position: absolute;
  left: 0;
  top: -2px;
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: var(--red);
  color: #fff;
  font-size: .85rem;
  font-weight: 700;
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

.faq-preview {
  border-top: 1px solid var(--dark-border);
}

@media (max-width: 1020px) {
  .hero {
    padding: 90px 0 60px;
  }
}

@media (max-width: 680px) {
  .hero {
    padding: 64px 0 48px;
  }

  .stats-grid,
  .feature-grid {
    grid-template-columns: 1fr;
  }

  .feature {
    justify-content: flex-start;
  }

  .hero-actions {
    flex-direction: column;
  }

  .hero-actions .btn {
    width: 100%;
  }
}
</style>
