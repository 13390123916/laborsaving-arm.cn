<script setup>
import { ref, computed, onMounted } from 'vue'
import { useHead } from '@vueuse/head'
import { useRoute, useRouter } from 'vue-router'
import Breadcrumb from '@/components/Breadcrumb.vue'
import { newsApi } from '@/api/content'
import { useJsonLd } from '@/composables/useJsonLd'
import fallbackData from '@/data/fallback.json'

const route = useRoute()
const router = useRouter()
const slug = route.params.slug

const article = ref(fallbackData.newsDetail)
const loading = ref(true)

onMounted(async () => {
  try {
    article.value = await newsApi.detail(slug)
  } catch {
    // fallback 已默认
  } finally {
    loading.value = false
  }
})

useHead(computed(() => ({
  title: article.value?.seo_title || article.value?.title || '资讯详情',
  meta: [
    { name: 'keywords', content: article.value?.seo_keywords || '机械臂资讯,雷普赛维' },
    { name: 'description', content: article.value?.seo_description || article.value?.summary || '' }
  ]
})))

const articleSchema = computed(() => ({
  '@context': 'https://schema.org',
  '@type': 'Article',
  headline: article.value?.title,
  description: article.value?.summary,
  author: { '@type': 'Organization', name: article.value?.author || '雷普赛维' },
  publisher: { '@type': 'Organization', name: '雷普赛维（LABOR-SAVING）', logo: 'https://www.example.com/logo.jpg' },
  datePublished: article.value?.published_at,
  dateModified: article.value?.updated_at || article.value?.published_at,
  url: `https://www.example.com/news/${slug}`
}))

useJsonLd('jsonld-article', articleSchema)
</script>

<template>
  <div class="news-detail-page">
    <div class="container">
      <Breadcrumb :items="[
        { path: '/news', label: '行业资讯' },
        { path: route.path, label: article?.title || '资讯详情' }
      ]" />
    </div>

    <section class="section section-dark" style="padding-top: 24px;">
      <div class="container">
        <article class="article-card">
          <div class="article-header">
            <span class="article-category">{{ article?.category_name }}</span>
            <h1 class="h2">{{ article?.title }}</h1>
            <div class="article-meta">
              <span>{{ article?.author }}</span>
              <span>{{ article?.published_at }}</span>
              <span v-if="article?.views">{{ article.views }} 阅读</span>
            </div>
          </div>
          <div class="article-body" v-html="article?.content" />
        </article>

        <div class="article-nav">
          <router-link to="/news" class="btn btn-ghost">← 返回资讯列表</router-link>
          <router-link to="/contact" class="btn btn-red">采购咨询</router-link>
        </div>
      </div>
    </section>
  </div>
</template>

<style scoped>
.article-card {
  background: var(--dark-card);
  border: 1px solid var(--dark-border);
  border-radius: var(--radius-lg);
  padding: 40px;
  max-width: 860px;
  margin: 0 auto;
}

.article-header {
  margin-bottom: 28px;
  padding-bottom: 24px;
  border-bottom: 1px solid var(--dark-border);
}

.article-category {
  display: inline-block;
  padding: 5px 12px;
  border-radius: 999px;
  background: rgba(227, 28, 37, .1);
  color: var(--red);
  font-size: .8rem;
  font-weight: 600;
  margin-bottom: 14px;
}

.article-header h1 {
  margin-bottom: 14px;
}

.article-meta {
  display: flex;
  gap: 16px;
  color: var(--text-on-dark-muted);
  font-size: .9rem;
  flex-wrap: wrap;
}

.article-body {
  color: #e5e5e5;
  line-height: 1.85;
  font-size: 1.05rem;
}

.article-body :deep(p) {
  margin-bottom: 18px;
}

.article-body :deep(h2),
.article-body :deep(h3) {
  margin-top: 32px;
  margin-bottom: 16px;
  color: #fff;
}

.article-body :deep(img) {
  max-width: 100%;
  border-radius: var(--radius);
  margin: 20px 0;
}

.article-nav {
  display: flex;
  justify-content: space-between;
  max-width: 860px;
  margin: 32px auto 0;
  gap: 16px;
  flex-wrap: wrap;
}

@media (max-width: 680px) {
  .article-card {
    padding: 24px;
  }

  .article-nav .btn {
    flex: 1 1 100%;
  }
}
</style>
