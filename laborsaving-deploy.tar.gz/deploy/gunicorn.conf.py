# LABOR-SAVING gunicorn 生产配置
# 部署路径：/opt/laborsaving/deploy/gunicorn.conf.py
# 仅监听本机 127.0.0.1:8000，由 Nginx 反向代理对外

import multiprocessing

bind = "127.0.0.1:8000"
workers = 3
worker_class = "sync"
threads = 2
timeout = 120
keepalive = 5
graceful_timeout = 30
max_requests = 1000
max_requests_jitter = 50

errorlog = "/opt/laborsaving/backend/gunicorn.error.log"
accesslog = "/opt/laborsaving/backend/gunicorn.access.log"
loglevel = "info"
