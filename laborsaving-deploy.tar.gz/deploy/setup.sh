#!/usr/bin/env bash
# ============================================================
#  LABOR-SAVING 一键部署脚本（服务器端）
#  用法（在 ECS 上解压部署包后执行）：
#    bash /opt/laborsaving/deploy/setup.sh
#  前置：部署包已解压到 /opt/laborsaving/
#       目录结构：/opt/laborsaving/{backend,frontend,deploy}
#  说明：本脚本已做「覆盖式重部署」加固——
#        会自动停用旧的 laborsaving 服务、禁用旧的 Nginx 站点配置、
#        释放 80 端口，再部署最新版本。可重复执行。
# ============================================================
set -euo pipefail

BASE=/opt/laborsaving
DEPLOY=$BASE/deploy
BACKEND=$BASE/backend

echo "==> [1/10] 检查运行权限"
if [ "$(id -u)" -ne 0 ]; then
  echo "请使用 root 运行：sudo bash $0"; exit 1
fi

echo "==> [2/10] 停用可能存在的旧部署（服务 / 80 端口）"
# 停用同名或常见旧服务，避免占用 80 端口
for s in laborsaving laborsaving-arm gunicorn django uwsgi; do
  systemctl stop "$s" 2>/dev/null || true
  systemctl disable "$s" 2>/dev/null || true
done
# 若 80 端口被非 nginx 进程占用（如旧 runserver / node），释放它
if command -v ss >/dev/null 2>&1; then
  OLD_PID=$(ss -ltnp 2>/dev/null | grep ':80 ' | grep -oP 'pid=\K[0-9]+' | head -1)
  if [ -n "$OLD_PID" ]; then
    # 若是 nginx 自身则跳过，否则结束该进程
    if ! ps -p "$OLD_PID" -o comm= 2>/dev/null | grep -q nginx; then
      echo "    释放 80 端口占用进程 PID=$OLD_PID"
      kill "$OLD_PID" 2>/dev/null || true
      sleep 1
    fi
  fi
fi

echo "==> [3/10] 安装系统依赖（nginx / python3 / venv / git）"
if command -v dnf >/dev/null 2>&1; then
  dnf install -y nginx python3 python3-pip python3-devel python3-venv git unzip
elif command -v yum >/dev/null 2>&1; then
  yum install -y nginx python3 python3-pip python3-devel python3-venv git unzip
else
  apt-get update && apt-get install -y nginx python3 python3-venv python3-pip git unzip
fi

echo "==> [4/10] 创建运行用户 laborsaving"
id -u laborsaving >/dev/null 2>&1 || useradd -r -s /sbin/nologin laborsaving

echo "==> [5/10] 创建 Python 虚拟环境并安装依赖"
python3 -m venv "$BACKEND/venv"
# shellcheck disable=SC1091
source "$BACKEND/venv/bin/activate"
pip install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple/
pip install -r "$DEPLOY/requirements-server.txt" -i https://mirrors.aliyun.com/pypi/simple/

echo "==> [6/10] 写入生产环境变量"
cp "$DEPLOY/.env" "$BACKEND/.env"
set -a; source "$BACKEND/.env"; set +a

echo "==> [7/10] Django 迁移 + 收集静态"
cd "$BACKEND"
python manage.py migrate --noinput
python manage.py collectstatic --noinput

echo "==> [8/10] 设置目录权限"
chown -R laborsaving:laborsaving "$BASE"
chmod 664 "$BACKEND/db.sqlite3"

echo "==> [9/10] 配置 Nginx（先禁用所有旧站点配置，再启用本站点）"
# 禁用 conf.d 下所有现有 server 配置，避免端口 / 域名冲突
if ls /etc/nginx/conf.d/*.conf >/dev/null 2>&1; then
  mkdir -p /etc/nginx/conf.d/disabled
  for f in /etc/nginx/conf.d/*.conf; do
    mv "$f" /etc/nginx/conf.d/disabled/ 2>/dev/null || true
  done
fi
cp "$DEPLOY/nginx_laborsaving.conf" /etc/nginx/conf.d/laborsaving.conf
nginx -t
systemctl enable nginx
systemctl restart nginx

echo "==> [10/10] 配置 gunicorn systemd 并启动"
cp "$DEPLOY/laborsaving.service" /etc/systemd/system/laborsaving.service
systemctl daemon-reload
systemctl enable laborsaving
systemctl restart laborsaving

# 防火墙（仅当 firewalld 运行时放行 80/443）
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --add-service=http
  firewall-cmd --permanent --add-service=https
  firewall-cmd --reload
fi

echo "=================================================="
echo " 部署完成！请检查服务状态："
echo "   systemctl status laborsaving   # gunicorn"
echo "   systemctl status nginx          # nginx"
echo "   验证首页： curl -sI http://127.0.0.1/ "
echo "   验证 API：  curl -s http://127.0.0.1/api/articles/ | head"
echo "=================================================="
