"""模板上下文处理器 — 向所有模板注入 FRONTEND_URL"""

from django.conf import settings


def frontend_url(request):
    """注入前台站点地址，供 Admin 模板中「查看前台」链接使用"""
    return {
        'FRONTEND_URL': getattr(settings, 'FRONTEND_URL', 'http://127.0.0.1:5173/'),
    }
